#include <stdio.h>
#include "functions.h"

int main(){
	print_hello();
	printf("\n");
	printf("The factorial of 5 is %d\n", factorial(5));
	return 0;
}
