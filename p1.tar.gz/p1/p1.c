// Michael Shipley
// CS-3060-X02 Fall 2021
// Assignment 1
#include <stdio.h>

int main (int argc, char *argv[]){
	printf("Michael Shipley's long awaited program 1\n");
	for (int i=0; i<argc; i++) {
		printf("Argument %d: %s \n", i, argv[i]);
	}
	printf("\nThe number of strings printed from command line entry was %d.\n", (argc-1));
}
