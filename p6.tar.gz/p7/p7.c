// Calculate logical address space
// Program... 6
#include <stdio.h> //printf
#include <stdlib.h> //strtol

//4KB addressable pages
#define PAGE_SIZE 4096

int main(int argc, char* argv[]){
	if(argc==1){
		printf("usage: ./p7 <hexidecimal address>\nGives the Logical Address, Page Index, and Offset for a hexidecimal address\n");
		return 1; //return nonzero
	}
	if(argc==2){
		char* address_as_str = argv[1];
		int long address_as_long = strtol(address_as_str, NULL, 16); //We will let the 0x address be used to assume hexadecimal
		int long page_index = address_as_long/PAGE_SIZE; //Should truncate, and make the adress at the page index in long form.
		int long offset = address_as_long%PAGE_SIZE; //Should create offset from a Page, by modulus.
		printf("Logical Addr:0x%08lX - Page Index:0x%08lX - Offset:0x%08lX\n",address_as_long, page_index, offset);
		return 0; //Exit safely
	}
}
