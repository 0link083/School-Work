// Michael Shipley
// Program 2: fork and exec, or the Executive Fork
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc, char* const argv[]) {
	pid_t cpid;
	if (fork() == 0) {//child
		printf ("Child Start\n");
		if (argc == 1) {
			printf("One argument provided. Calling execlp(), he was so young.\n");
			execlp(argv[1],*argv, NULL);
		}
		else {
			printf("More than one argument provided. Calling execvp(), the odds were too great.\n");
			execvp(argv[1],argv);
		}
	}
	else {//parent
		printf ("Parent process has started.\n");
		cpid = wait(NULL); //Should wait unil the child exits.
		printf ("Child ID#%d is gone, I will go on no more.\n", cpid); //Child termminated, now the parent terminates
	}
	return 0;
}
