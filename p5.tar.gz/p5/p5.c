#ifndef Project5
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

#define BUFFER_SIZE (20)
#define MAX_INT 65536

int *buffer;
int counter;
int in;
int out;

void *producer(void *ptr) {
	int value = atoi(ptr); //Turns our argument into a proper int
	while (counter<BUFFER_SIZE) {
		buffer[in] = value++;
		in = (in + 1) % BUFFER_SIZE;
		counter++;
		printf("buffer[%i]: %i\n",in,buffer[in]);
	}
	pthread_exit(0);
}

/*
void *consumer(void *ptr) {
	int last = (int)(ptr);
	while (last < MAX_INT) {
		while (counter == 0)
			; // do nothing 

		last++;

		if (last != buffer[out]) {
			printf("Error at value %d! I was expecting %d\n", buffer[out], last);
			exit(-1);
		}

		out = (out + 1) % BUFFER_SIZE;
		counter--;
	}
	pthread_exit(0);
}
*/
int main(int argc,char* argv[]) {
	if(argc==1){
		printf("usage: p5 <int>, takes int and gives factors of it.\n");
		return(-1); //Not the usage of the program.
	}
	pthread_t produce;
//	pthread_t consume;
	buffer = malloc(sizeof(int) * BUFFER_SIZE);
	counter = 0;
	in = 0;
	out = 0;

	printf("%p\n",argv[1]);
	pthread_create(&produce, NULL, producer, argv[1]);

//	pthread_create(&consume, NULL, consumer, argv[1]);

	pthread_join(produce, NULL);
//	pthread_join(consume, NULL);

	return 0;
}
#endif
