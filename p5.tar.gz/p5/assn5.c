// Program 5 pthreads
// Michael Shipley CS 3060 Fall 2021
// Based on code from assn3
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h> // for malloc and free
#include <semaphore.h>

#define BUFFER_SIZE 20

struct thread_Memory {
	int pbuffer;
	int cbuffer[BUFFER_SIZE];
	int argc;
	int c_counter;
	int p_counter;
	int isReady;
	int isReadyToo;
};

sem_t prod_mutex; //Producer<->Main
sem_t cons_mutex; //Producer<->Consumer
sem_t print_lock;

void *producer(void* ptr) {
	struct thread_Memory* threadMemory = (struct thread_Memory*) ptr; //Now ideally we are passing in the struct

       	// printf(":%i::%i:", threadMemory->p_counter,threadMemory->argc);	
	while(threadMemory->p_counter > 0){
		for(;;){ // Wait until there is stuff in the buffer.
                        sem_wait(&prod_mutex);
                        if (threadMemory->isReadyToo == 1){
                                break;
                        }
                        sem_post(&prod_mutex);
                }
        	int c = threadMemory->pbuffer; // This will be the buffer shared between main and producer, it gives values for factoring
		sem_post(&prod_mutex);
		sem_wait(&cons_mutex);
		if(threadMemory->pbuffer == 1){
			threadMemory->cbuffer[0] = threadMemory->pbuffer;
		}
		else{
	        	int i = 3; // This is our factor.
        		int j = 0; // This is to keep track of where we are in our output.
        		while( c%2 == 0 && c>3){
				threadMemory->cbuffer[j] = 2;

				j++;
                		c = c/2;
        		}
        		while (i*i <= c) {
	                	if(c%i==0){
					threadMemory->cbuffer[j] = i;
                        	
					j++;
                	        	c = c/i;
        	        	}
	               		else{
                        		i= i+2;
                		}
        		}
        		if (c!=1 && c!=0) {
	                	threadMemory->cbuffer[j] = c;
        		}
		}
		threadMemory->isReady = 1; // Set ready state for consumer to accept numbers.
		sem_post(&cons_mutex);
		sem_wait(&prod_mutex);
		threadMemory->p_counter--;
		threadMemory->isReadyToo = 0;
		sem_post(&prod_mutex);
	}
        pthread_exit(0);
}

void *consumer(void* ptr) {
	struct thread_Memory* threadMemory = (struct thread_Memory*)ptr;

	for(int i = 0; i < threadMemory->argc-1; i++){
		for(;;){ // Wait until there is stuff in the buffer.
                       	sem_wait(&cons_mutex);
                       	if (threadMemory->isReady == 1){ // Only allows printing one when the set is finished.
                       	        sem_post(&cons_mutex);
				break;
                       	}
                       	sem_post(&cons_mutex);
               	}
               	sem_wait(&prod_mutex); 
               	printf("%d:", threadMemory->pbuffer);
		sem_post(&prod_mutex);
		sem_wait(&cons_mutex);
		for( int j = 0; j < BUFFER_SIZE; j++){
			int temp = threadMemory->cbuffer[j];
			threadMemory->cbuffer[j] = 0;
			if(temp != 0) {
				printf(" %d",temp); //Prints each factor.
			}
               	}
		threadMemory->isReady=0;
		sem_post(&cons_mutex);
               	printf("\n"); // Just an endl. Move along, move along.
	}

	pthread_exit(0);
}

int main (int argc, char* argv[]) {
	if(argc == 1) {
                printf("usage: ./assn5 <number to factor> ...\n");
                // free(threadMemory); //always pair your frees and mallocs.
                return 0; //This is an acceptable use.
        }
	
	sem_init(&prod_mutex, 0, 1); // initialize the mutex to be shared between main and producer
	sem_init(&cons_mutex, 0, 1); // initialize the mutex to be shared between main and producer
	sem_init(&print_lock, 0, 1); // print lock for printf

	pthread_t t1,t2; //Thread IDs 

	struct thread_Memory* threadMemory = malloc((sizeof(int*) * BUFFER_SIZE)+(sizeof(int) * 7)); //THIS IS THE PROBLEM CHILD
	
	threadMemory->argc = argc;
	threadMemory->c_counter = argc-1;
	threadMemory->p_counter = argc-1;
	threadMemory->isReady = 0;
	threadMemory->isReadyToo = 0;
	//printf(":%d:%d:\n", argc, threadMemory->argc);

	pthread_create(&t1,NULL,producer,(void*)threadMemory);

	pthread_create(&t2,NULL,consumer,(void*)threadMemory);	

	for (int i = 0; i < argc-1; ++i) {
		for(;;){
			sem_wait(&prod_mutex);//isReadyToo
			sem_wait(&cons_mutex);//isReady
			if(threadMemory->isReady == 0 && threadMemory->isReadyToo == 0) {
				sem_post(&cons_mutex);
				break;
			}
			sem_post(&prod_mutex);
			sem_post(&cons_mutex);
		}
		threadMemory->pbuffer = atoi(argv[i+1]);
		threadMemory->isReadyToo = 1;
		sem_post(&prod_mutex);
	}
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);

	free(threadMemory);
	return 0;
}

