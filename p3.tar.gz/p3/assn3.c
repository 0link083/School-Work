// Program 3 pthreads
// Michael Shipley CS 3060 Fall 2021
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h> // for malloc and free

#define BUFFER_SIZE 20

void *findFactors(void *ptr);

int threadMemory[BUFFER_SIZE][BUFFER_SIZE];
pthread_t *tid;

/* 
 * This was a fialed attmept of the use of a struct, it fell through when I made an array of structs.
struct container {
	int input; //Number to be factored
	int output[BUFFER_SIZE]; // It actually would be better as log base 2 of input. but hey. I work with what I got. 
};
*/

int main (int argc, char* argv[]) {
	if(argc == 1) {
                printf("usage: ./assn3 <number to factor> ...\n");
                // free(threadMemory); //always pair your frees and mallocs.
                return 0; //This is an acceptable use.
        }

	int temp[argc-1];

	pthread_t tid[argc-1]; //Thread IDs in an array
	//struct container *threadMemory [(argc)]; // Make an array of struct containers that hold our values for processing.
	//	threadMemory[argc-1][BUFFER_SIZE]; 
	//The 1st level array will reflect an id for each element in argv, the second will hold values for factors

	for (int i = 0; i < argc-1;  ++i) {
		temp[i] = tid[i] = i;
		for (int j =0; j < BUFFER_SIZE; ++j) {
			threadMemory[i][j] = 0;
		}
	}

	for(int i = 0; i < argc-1; ++i) {
		//pthread_attr(&attr); //Default Attributes
	
		// printf("Creating Thread %i\n",i);
	
		threadMemory[i][0] = atoi(argv[i+1]); //The input in the array for our struct is assigned our argument.
	 	int p = i; //safety concerns bid me to duplicate the index before entry.
		
		//printf("int* p = :%p:\n", &p);
		
		temp[i] = pthread_create(&tid[i],NULL,&findFactors,(void*)&p);
	
	  	if (temp[i] != 0){
	 		printf("Thread Creation Error at %i\n", i);
		       	exit(-1);	
	 	}
	
		// printf("temp[i] = %i\n", temp[i]);
		
		//create the thread in the array of threads, with default attributes, 
		//give it the function handle for our equation, and the struct as a perameter for that function. 
	} 
	// I am hoping this breakup will keep anything from joining before anything is created.
	for(int i = 0; i < argc-1; i++){
		pthread_join(tid[i], NULL); // Should wait till they are done asyncronously. And place the innerArray at threadMemory[i]
		
		printf("\n%s: ",argv[i+1]);
		
		for( int j =0; j < BUFFER_SIZE; j++){
			if (threadMemory[i][j] == 0) break;
			printf("%d ",threadMemory[i][j]); //Prints each factor.
		}
		printf("\n"); // Just an endl.
	}
	// free(threadMemory);
	return 0;
}

void *findFactors(void* value){
	int self = *(int*)value;
	
	//printf("thread id :%lu: running findFactors\n", pthread_self());
	
	int c = threadMemory[self][0]; // I should have stored my input value in the first slot of my buffer.
	
	// printf("memory access complete\n");
	
	int i = 3; // This is our factor.
	int j = 0; // This is to keep track of where we are in our output.
	while( c%2 ==0)
	{
		threadMemory[self][j%BUFFER_SIZE] = 2;//Please don't give me more than 20 factors.
		j++;
		c = c/2;
	}
	while (i*i <= c) {
		if(c%i==0){
			threadMemory[self][j%BUFFER_SIZE] = i;
			j++;
			c = c/i;
		}
		else{
			i= i+2;
		}	
	}
	if (c!=1 && c!=0) {
		threadMemory[self][j%BUFFER_SIZE] = c;
	}
	threadMemory[self][(j+1)%BUFFER_SIZE] = 0; //This gives me a terminating number after the factors ALWAYS. 
	
	// printf("exiting :%lu:\n", pthread_self());
	
	pthread_exit(0);
}
