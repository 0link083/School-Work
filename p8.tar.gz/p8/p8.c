#define _GNU_SOURCE

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

void do_ls(char []);

unsigned int byte_count=0;

int main (int ac, char *av[]){
	if ( ac == 1 )
		do_ls(".");
	else
		while (--ac){
			printf("%s:\n", *++av);
			do_ls( *av);
	}
	printf("Total file space used:%i\n", byte_count);
}
void do_ls(char dirname[]){
	DIR *dir_ptr;
	struct dirent *direntp;
	struct stat info;
	char* path = dirname;
	if ((dir_ptr = opendir( dirname)) == NULL)
		fprintf(stderr, "p8: cannot open %s\n", dirname);
	else
	{
		while ((direntp = readdir(dir_ptr)) != NULL){
			//stat(direntp->d_name, &info);     
			if(lstat(direntp->d_name, &info)!=0){
				//stat(direntp->d_name, &info);
				printf("%d %s\n", (int)info.st_size, direntp->d_name);
				byte_count+=(int)info.st_size;
				//Exiting is probably good.
			}
			else if (S_ISDIR(info.st_mode)) {
				char* directoryName;
				asprintf(&directoryName,"%s",direntp->d_name);
				char* badString1 = ".";
				char* badString2 = "..";
				if(strcmp(directoryName, badString1) != 0 && strcmp(directoryName, badString2) != 0) { //Prevent looping
					printf("DIR %s\n", directoryName);
                               		asprintf(&path, "%s/%s",path,directoryName);
					do_ls(path);
				}
				free(directoryName);
			}
			else if(S_ISREG(info.st_mode)) {
				printf("%d %s\n", (int)info.st_size, direntp->d_name);
				byte_count+=(int)info.st_size;
			}
		}
		closedir(dir_ptr);
	}
}
